﻿namespace Local_Vinyl_Player
{
    partial class UploadForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wavButton = new System.Windows.Forms.Button();
            this.coverButton = new System.Windows.Forms.Button();
            this.albumCoverLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.albumNameTextbox = new System.Windows.Forms.TextBox();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.submitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wavButton
            // 
            this.wavButton.Location = new System.Drawing.Point(82, 97);
            this.wavButton.Name = "wavButton";
            this.wavButton.Size = new System.Drawing.Size(100, 35);
            this.wavButton.TabIndex = 0;
            this.wavButton.Text = "Choose File";
            this.wavButton.UseVisualStyleBackColor = true;
            this.wavButton.Click += new System.EventHandler(this.wavButton_Click);
            // 
            // coverButton
            // 
            this.coverButton.Location = new System.Drawing.Point(82, 37);
            this.coverButton.Name = "coverButton";
            this.coverButton.Size = new System.Drawing.Size(100, 35);
            this.coverButton.TabIndex = 1;
            this.coverButton.Text = "Choose File";
            this.coverButton.UseVisualStyleBackColor = true;
            this.coverButton.Click += new System.EventHandler(this.coverButton_Click);
            // 
            // albumCoverLabel
            // 
            this.albumCoverLabel.AutoSize = true;
            this.albumCoverLabel.Location = new System.Drawing.Point(78, 19);
            this.albumCoverLabel.Name = "albumCoverLabel";
            this.albumCoverLabel.Size = new System.Drawing.Size(107, 15);
            this.albumCoverLabel.TabIndex = 2;
            this.albumCoverLabel.Text = "Select album cover";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(91, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select .wav file";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Input album name";
            // 
            // albumNameTextbox
            // 
            this.albumNameTextbox.Location = new System.Drawing.Point(46, 157);
            this.albumNameTextbox.Name = "albumNameTextbox";
            this.albumNameTextbox.Size = new System.Drawing.Size(170, 23);
            this.albumNameTextbox.TabIndex = 5;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(149, 187);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(102, 35);
            this.cancelBtn.TabIndex = 6;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // submitBtn
            // 
            this.submitBtn.Location = new System.Drawing.Point(12, 187);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(102, 35);
            this.submitBtn.TabIndex = 7;
            this.submitBtn.Text = "Submit";
            this.submitBtn.UseVisualStyleBackColor = true;
            this.submitBtn.Click += new System.EventHandler(this.submitBtn_Click);
            // 
            // UploadForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(263, 236);
            this.Controls.Add(this.submitBtn);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.albumNameTextbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.albumCoverLabel);
            this.Controls.Add(this.coverButton);
            this.Controls.Add(this.wavButton);
            this.Name = "UploadForm";
            this.Text = "UploadForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button wavButton;
        private Button coverButton;
        private Label albumCoverLabel;
        private Label label1;
        private Label label2;
        private TextBox albumNameTextbox;
        private Button cancelBtn;
        private Button submitBtn;
    }
}