﻿using System.Resources;
using System.Windows.Forms;

namespace Local_Vinyl_Player
{
    public partial class UploadForm : Form
    {
        private string albumCoverPath; // File path for album cover
        private string albumCoverExt; // File extension of image
        private string wavPath; // File path for wav file
        private string albumName; // Name of album
        private string resourceFile = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "\\Properties\\Resources.resx");
        public UploadForm()
        {
            InitializeComponent();
            this.CenterToScreen(); // Center GUI
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Dispose(); // Close GUI
        }

        private void UploadForm_FormClosing(object sender, EventArgs e)
        {
            this.Dispose(); // Close GUI
        }

        private void coverButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Image files (*.jpg)|*.jpg";
            openFileDialog.FilterIndex = 0;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                albumCoverPath = openFileDialog.FileName;
                albumCoverExt = "." + openFileDialog.FileName.Split('\\').Last().Split('.').Last();
            }
        }

        private void wavButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "Wave files (*.wav)|*.wav";
            openFileDialog.FilterIndex = 0;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                wavPath = openFileDialog.FileName;
            }
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            albumName = albumNameTextbox.Text; // Set album name
            if (albumName != "")
            {
                Form1 f = new Form1(); // Instantiate form object
                f.albumList.AddLast(albumName); // Add album name to album list
                File.Copy(albumCoverPath, f.albumCoverPath + albumName + albumCoverExt); // Copy album cover path to resources folder
                File.Copy(wavPath, f.wavPath + albumName + ".wav"); // Copy wav file path to resources folder
                this.Dispose();
                f.UpdateAlbumImages();
            }
        }
    }
}
