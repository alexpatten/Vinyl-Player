﻿namespace Local_Vinyl_Player
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.midAlbum = new System.Windows.Forms.PictureBox();
            this.nextButton = new System.Windows.Forms.PictureBox();
            this.pauseButton = new System.Windows.Forms.PictureBox();
            this.playButton = new System.Windows.Forms.PictureBox();
            this.backButton = new System.Windows.Forms.PictureBox();
            this.leftSliderButton = new System.Windows.Forms.PictureBox();
            this.rightSliderButton = new System.Windows.Forms.PictureBox();
            this.xButton = new System.Windows.Forms.PictureBox();
            this.circle = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.uploadButton = new System.Windows.Forms.PictureBox();
            this.trashButton = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.midAlbum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nextButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pauseButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftSliderButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightSliderButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.circle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uploadButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trashButton)).BeginInit();
            this.SuspendLayout();
            // 
            // midAlbum
            // 
            this.midAlbum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.midAlbum.Location = new System.Drawing.Point(209, 205);
            this.midAlbum.Name = "midAlbum";
            this.midAlbum.Size = new System.Drawing.Size(622, 474);
            this.midAlbum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.midAlbum.TabIndex = 5;
            this.midAlbum.TabStop = false;
            this.midAlbum.Click += new System.EventHandler(this.midAlbum_Click);
            // 
            // nextButton
            // 
            this.nextButton.BackColor = System.Drawing.Color.Transparent;
            this.nextButton.Image = global::Local_Vinyl_Player.Properties.Resources.media_skip_forward;
            this.nextButton.Location = new System.Drawing.Point(625, 677);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(100, 50);
            this.nextButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.nextButton.TabIndex = 9;
            this.nextButton.TabStop = false;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // pauseButton
            // 
            this.pauseButton.BackColor = System.Drawing.Color.Transparent;
            this.pauseButton.Image = global::Local_Vinyl_Player.Properties.Resources.media_playback_pause;
            this.pauseButton.Location = new System.Drawing.Point(409, 701);
            this.pauseButton.Name = "pauseButton";
            this.pauseButton.Size = new System.Drawing.Size(100, 50);
            this.pauseButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pauseButton.TabIndex = 10;
            this.pauseButton.TabStop = false;
            this.pauseButton.Click += new System.EventHandler(this.pauseButton_Click);
            // 
            // playButton
            // 
            this.playButton.BackColor = System.Drawing.Color.Transparent;
            this.playButton.Image = ((System.Drawing.Image)(resources.GetObject("playButton.Image")));
            this.playButton.Location = new System.Drawing.Point(519, 701);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(100, 50);
            this.playButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playButton.TabIndex = 11;
            this.playButton.TabStop = false;
            this.playButton.Click += new System.EventHandler(this.playButton_Click);
            // 
            // backButton
            // 
            this.backButton.BackColor = System.Drawing.Color.Transparent;
            this.backButton.Image = global::Local_Vinyl_Player.Properties.Resources.media_skip_backward;
            this.backButton.Location = new System.Drawing.Point(303, 677);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(100, 50);
            this.backButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.backButton.TabIndex = 12;
            this.backButton.TabStop = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // leftSliderButton
            // 
            this.leftSliderButton.BackColor = System.Drawing.Color.Transparent;
            this.leftSliderButton.Image = global::Local_Vinyl_Player.Properties.Resources.slider_left;
            this.leftSliderButton.Location = new System.Drawing.Point(113, 423);
            this.leftSliderButton.Name = "leftSliderButton";
            this.leftSliderButton.Size = new System.Drawing.Size(33, 30);
            this.leftSliderButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.leftSliderButton.TabIndex = 14;
            this.leftSliderButton.TabStop = false;
            this.leftSliderButton.Click += new System.EventHandler(this.leftSliderButton_Click);
            this.leftSliderButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.leftSliderButton_MouseDown);
            this.leftSliderButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.leftSliderButton_MouseUp);
            // 
            // rightSliderButton
            // 
            this.rightSliderButton.BackColor = System.Drawing.Color.Transparent;
            this.rightSliderButton.Image = ((System.Drawing.Image)(resources.GetObject("rightSliderButton.Image")));
            this.rightSliderButton.Location = new System.Drawing.Point(890, 423);
            this.rightSliderButton.Name = "rightSliderButton";
            this.rightSliderButton.Size = new System.Drawing.Size(33, 30);
            this.rightSliderButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rightSliderButton.TabIndex = 15;
            this.rightSliderButton.TabStop = false;
            this.rightSliderButton.Click += new System.EventHandler(this.rightSliderButton_Click);
            this.rightSliderButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.rightSliderButton_MouseDown);
            this.rightSliderButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.rightSliderButton_MouseUp);
            // 
            // xButton
            // 
            this.xButton.BackColor = System.Drawing.Color.Transparent;
            this.xButton.Image = global::Local_Vinyl_Player.Properties.Resources.x;
            this.xButton.Location = new System.Drawing.Point(480, 29);
            this.xButton.Name = "xButton";
            this.xButton.Size = new System.Drawing.Size(60, 60);
            this.xButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.xButton.TabIndex = 16;
            this.xButton.TabStop = false;
            this.xButton.Click += new System.EventHandler(this.xButton_Click);
            this.xButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xButton_MouseDown);
            this.xButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xButton_MouseUp);
            // 
            // circle
            // 
            this.circle.BackColor = System.Drawing.Color.Transparent;
            this.circle.Image = global::Local_Vinyl_Player.Properties.Resources.Circle;
            this.circle.Location = new System.Drawing.Point(480, 411);
            this.circle.Name = "circle";
            this.circle.Size = new System.Drawing.Size(65, 56);
            this.circle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.circle.TabIndex = 17;
            this.circle.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(265, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 18;
            // 
            // uploadButton
            // 
            this.uploadButton.BackColor = System.Drawing.Color.Transparent;
            this.uploadButton.Image = ((System.Drawing.Image)(resources.GetObject("uploadButton.Image")));
            this.uploadButton.Location = new System.Drawing.Point(197, 652);
            this.uploadButton.Name = "uploadButton";
            this.uploadButton.Size = new System.Drawing.Size(100, 50);
            this.uploadButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.uploadButton.TabIndex = 19;
            this.uploadButton.TabStop = false;
            this.uploadButton.Click += new System.EventHandler(this.uploadButton_Click);
            // 
            // trashButton
            // 
            this.trashButton.BackColor = System.Drawing.Color.Transparent;
            this.trashButton.Image = ((System.Drawing.Image)(resources.GetObject("trashButton.Image")));
            this.trashButton.Location = new System.Drawing.Point(731, 652);
            this.trashButton.Name = "trashButton";
            this.trashButton.Size = new System.Drawing.Size(100, 50);
            this.trashButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.trashButton.TabIndex = 20;
            this.trashButton.TabStop = false;
            this.trashButton.Click += new System.EventHandler(this.trashButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Local_Vinyl_Player.Properties.Resources.Vinyl;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1032, 878);
            this.Controls.Add(this.trashButton);
            this.Controls.Add(this.uploadButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.circle);
            this.Controls.Add(this.xButton);
            this.Controls.Add(this.rightSliderButton);
            this.Controls.Add(this.leftSliderButton);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.pauseButton);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.midAlbum);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Vinyl Player";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.midAlbum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nextButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pauseButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftSliderButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightSliderButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.circle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uploadButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trashButton)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox midAlbum;
        private PictureBox nextButton;
        private PictureBox pauseButton;
        private PictureBox playButton;
        private PictureBox backButton;
        private PictureBox leftSliderButton;
        private PictureBox rightSliderButton;
        private PictureBox xButton;
        private PictureBox circle;
        private Label label1;
        private PictureBox uploadButton;
        private PictureBox trashButton;
    }
}