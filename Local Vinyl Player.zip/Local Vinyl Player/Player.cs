﻿using System.Runtime.InteropServices;
using System.Text;
using System;
using static System.Windows.Forms.DataFormats;

namespace Local_Vinyl_Player
{
    class Player : IDisposable
    {
        private string projectPath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
        private string albumCoverPath = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "Resources\\Images\\Covers\\"); // String for album cover path
        private string wavPath = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "Resources\\Music\\"); // String for album path
        public bool repeat { get; set; }

        [DllImport("winmm.dll")]
        private static extern long mciSendString(string strCommand, StringBuilder strReturn, int iReturnLength, int hwdCallBack);

        public void Dispose()
        {
            string command = "close MediaFile";
            mciSendString(command, null, 0, 0);
        }

        public void Mp3Player(string album)
        {
            // Dispose last object, if applicable
            Dispose();
            const string format = @"open ""{0}"" type mpegvideo alias MediaFile";
            string command = String.Format(format, album);
            mciSendString(command, null, 0, 0);
            Play();
        }
        public void Play()
        {
            string command = "play MediaFile";
            if (repeat) command += " REPEAT";
            mciSendString(command, null, 0, 0);
        }
        public void Stop()
        {
            string command = "stop MediaFile";
            mciSendString(command, null, 0, 0);
        }
    }
}
