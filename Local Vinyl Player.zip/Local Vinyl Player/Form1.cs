using System.Drawing.Drawing2D;

namespace Local_Vinyl_Player
{
    public partial class Form1 : Form
    {
        // Instanstiate player object
        private Player play = new Player();
        // Variables to move GUI
        private const int WM_NCHITTEST = 0x84;
        private const int HTCLIENT = 0x1;
        private const int HTCAPTION = 0x2;
        // Setup array for album names
        public LinkedList<string> albumList;
        // Get project path
        public string projectPath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
        public string albumCoverPath = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "Resources\\Images\\Covers\\"); // String for album cover path
        public string wavPath = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "Resources\\Music\\"); // String for album path

        public Form1()
        {
            InitializeComponent();
            // Overlap circle on middle image
            midAlbum.Controls.Add(circle); // Add circle to middle image
            circle.Location = new Point(275, 215); // Move to center
            circle.BackColor = Color.Transparent; // Make transparent
            // Overlap left slider on left image
            midAlbum.Controls.Add(leftSliderButton); // Add slider to right image
            leftSliderButton.Location = new Point(10, 225); // Move to center
            leftSliderButton.BackColor = Color.Transparent; // Make transparent
            // Overlap right slider on right image
            midAlbum.Controls.Add(rightSliderButton); // Add slider to right image
            rightSliderButton.Location = new Point(575, 225); // Move to center
            rightSliderButton.BackColor = Color.Transparent; // Make transparent
            albumList = new LinkedList<string>(); // Create new album list
            // For each file in album path
            foreach(string file in Directory.GetFiles(wavPath, "*.wav", SearchOption.TopDirectoryOnly)){
                albumList.AddLast(file); // Add file name and path to albumList
            }
            UpdateAlbumImages(); // Update album cover images
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            gp.AddEllipse(0, 0, midAlbum.Width - 3, midAlbum.Height - 3);
            Region rg = new Region(gp);
            midAlbum.Region = rg;
        }
        public void UpdateAlbumImages()
        {
            string albumString = albumList.ElementAt(0).Split('\\').Last().Split('.').First(); // String for album and remove path before file name
            Image img = Image.FromFile(albumCoverPath + albumString + ".jpg");
            //midAlbum.Image = (Image)Properties.Resources.ResourceManager.GetObject(albumString + "Cover"); // Update album cover image
            midAlbum.Image = img;
        }

        // Make GUI movable
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case WM_NCHITTEST:
                    base.WndProc(ref m);

                    if ((int)m.Result == HTCLIENT)
                        m.Result = (IntPtr)HTCAPTION;
                    return;
            }

            base.WndProc(ref m);
        }

        // When middle album is clicked
        private void midAlbum_Click(object sender, EventArgs e)
        {
            string album = albumList.ElementAt(0); // String for middle album
            play.Mp3Player(album); // Play middle album
        }
        // When pause button is clicked
        private void pauseButton_Click(object sender, EventArgs e)
        {
            play.Stop(); // Pause music
        }
        // When play button is clicked
        private void playButton_Click(object sender, EventArgs e)
        {
            play.Play(); // Play or resume
        }
        // When next button is clicked
        private void nextButton_Click(object sender, EventArgs e)
        {
            // Play next album or song
        }
        //When previous button is clicked
        private void backButton_Click(object sender, EventArgs e)
        {
            // Play previous album or song
        }
        // When upload button is clicked
        private void uploadButton_Click(object sender, EventArgs e)
        {
            UploadForm uf = new UploadForm();
            uf.Show();
        }
        // When trash button is clicked
        private void trashButton_Click(object sender, EventArgs e)
        {

        }
        // When form loads
        private void Form1_Load(object sender, EventArgs e)
        {
            // Remove border form
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            // Graphics path setup
            var path = new GraphicsPath();
            // Add ellipse
            path.AddEllipse(6, 10, Width-10, Height-23);
            // Setup GUI as ellipse
            Region = new Region(path);
            // Center GUI
            this.CenterToScreen();
        }
        // When mouseclick is held down on left slider button
        private void leftSliderButton_MouseDown(object sender, MouseEventArgs e)
        {
            leftSliderButton.Image = Properties.Resources.slider_left_click; // Change left click slider image
        }
        // When mouseclick is up on left slider button
        private void leftSliderButton_MouseUp(object sender, MouseEventArgs e)
        {
            leftSliderButton.Image = Properties.Resources.slider_left; // Change left click slider image
        }
        // When mouse is held down on right slider button
        private void rightSliderButton_MouseDown(object sender, MouseEventArgs e)
        {
            rightSliderButton.Image = Properties.Resources.slider_right_click; // Change right click slider image
        }
        // When mouseclick is up on right slider button
        private void rightSliderButton_MouseUp(object sender, MouseEventArgs e)
        {
            rightSliderButton.Image = Properties.Resources.slider_right; // Change right click slider image
        }
        // When mouseclick is held down on X button
        private void xButton_MouseDown(object sender, MouseEventArgs e)
        {
            
        }
        // When mouseclick is up on X button
        private void xButton_MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            //capture left arrow key
            if (keyData == Keys.Left)
            {
                SortLeft();
                return true;
            }
            //capture right arrow key
            if (keyData == Keys.Right)
            {
                SortRight();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        // Sort albums to left
        private void leftSliderButton_Click(object sender, EventArgs e)
        {
            SortLeft();
        }

        // Sort albums to right
        private void rightSliderButton_Click(object sender, EventArgs e)
        {
            SortRight();
        }

        private void SortLeft()
        {
            albumList.AddFirst(albumList.Last()); // Add first element using last element from albumList
            albumList.RemoveLast(); // Remove last element
            UpdateAlbumImages(); // Update album cover images
        }
        private void SortRight()
        {
            albumList.AddLast(albumList.First()); // Add last element using first element from albumList
            albumList.RemoveFirst(); // Remove first element
            UpdateAlbumImages(); // Update album cover images
        }

        // Close form
        private void xButton_Click(object sender, EventArgs e)
        {
            this.Dispose(); // Close GUI
        }
    }
}